var searchbox=document.getElementById("search1")
var container=document.querySelector(".product-box")
var elements=container.querySelectorAll("div")


 
search1.addEventListener("onkeyup",function(){
    enteredText=event.target.value.toUpperCase()
    for(i=0;i<elements.length;i++)
        if(elements[i].textContent.toUpperCase().indexOf(enteredText)<0){
            elements[i].style.display="none"
        }
        else{
            elements[i].style.display="block"
        }

})



    

